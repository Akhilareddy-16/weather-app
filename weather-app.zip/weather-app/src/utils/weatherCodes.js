// WMO Weather Interpretation Codes
// Source: https://open-meteo.com/en/docs

export const WMO_CODES = {
  0:  ["Clear Sky",               "☀️"],
  1:  ["Mainly Clear",            "🌤️"],
  2:  ["Partly Cloudy",           "⛅"],
  3:  ["Overcast",                "☁️"],
  45: ["Foggy",                   "🌫️"],
  48: ["Icy Fog",                 "🌫️"],
  51: ["Light Drizzle",           "🌦️"],
  53: ["Drizzle",                 "🌦️"],
  55: ["Heavy Drizzle",           "🌧️"],
  61: ["Light Rain",              "🌧️"],
  63: ["Moderate Rain",           "🌧️"],
  65: ["Heavy Rain",              "🌧️"],
  71: ["Light Snow",              "🌨️"],
  73: ["Moderate Snow",           "❄️"],
  75: ["Heavy Snow",              "❄️"],
  77: ["Snow Grains",             "❄️"],
  80: ["Light Showers",           "🌦️"],
  81: ["Showers",                 "🌧️"],
  82: ["Heavy Showers",           "⛈️"],
  85: ["Snow Showers",            "🌨️"],
  86: ["Heavy Snow Showers",      "❄️"],
  95: ["Thunderstorm",            "⛈️"],
  96: ["Thunderstorm w/ Hail",    "⛈️"],
  99: ["Thunderstorm Heavy Hail", "⛈️"],
};

export const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

/**
 * Returns [description, emoji] for a given WMO weather code.
 * Falls back to ["Unknown", "🌡️"] if code not found.
 */
export function getWeatherInfo(code) {
  return WMO_CODES[code] || ["Unknown", "🌡️"];
}

/**
 * Returns day label — "Today" for index 0, short day name otherwise.
 */
export function getDayLabel(dateString, index) {
  if (index === 0) return "Today";
  const d = new Date(dateString + "T00:00:00");
  return DAYS[d.getDay()];
}
