// All API calls live here — easy to swap endpoints later

const GEO_BASE = "https://geocoding-api.open-meteo.com/v1";
const WEATHER_BASE = "https://api.open-meteo.com/v1";

/**
 * Converts a city name to lat/lon using Open-Meteo Geocoding API.
 * Returns the first matching result object.
 * Throws if city is not found.
 */
export async function geocodeCity(cityName) {
  const url = `${GEO_BASE}/search?name=${encodeURIComponent(cityName)}&count=1&language=en&format=json`;
  const res = await fetch(url);

  if (!res.ok) throw new Error("Geocoding service unavailable. Try again later.");

  const data = await res.json();

  if (!data.results || data.results.length === 0) {
    throw new Error(`City "${cityName}" not found. Please check the spelling.`);
  }

  return data.results[0];
}

/**
 * Fetches current weather + 7-day forecast for given coordinates.
 * Returns the full Open-Meteo forecast response.
 */
export async function fetchForecast(latitude, longitude) {
  const params = new URLSearchParams({
    latitude,
    longitude,
    current:
      "temperature_2m,apparent_temperature,relative_humidity_2m,wind_speed_10m,weather_code",
    daily:
      "temperature_2m_max,temperature_2m_min,weather_code,precipitation_probability_max",
    forecast_days: 7,
    timezone: "auto",
  });

  const url = `${WEATHER_BASE}/forecast?${params}`;
  const res = await fetch(url);

  if (!res.ok) throw new Error("Weather service unavailable. Try again later.");

  return res.json();
}
