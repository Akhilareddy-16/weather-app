import ForecastCard from "./ForecastCard";
import styles from "../styles/Forecast.module.css";

/**
 * Forecast — renders the 7-day forecast grid.
 * Props:
 *   daily — weather.daily object from Open-Meteo
 */
export default function Forecast({ daily }) {
  return (
    <div className={styles.section}>
      <p className={styles.title}>7-Day Forecast</p>
      <div className={styles.grid}>
        {daily.time.map((dateStr, i) => (
          <ForecastCard
            key={dateStr}
            dateString={dateStr}
            index={i}
            maxTemp={daily.temperature_2m_max[i]}
            minTemp={daily.temperature_2m_min[i]}
            weatherCode={daily.weather_code[i]}
            rainChance={daily.precipitation_probability_max[i]}
          />
        ))}
      </div>
    </div>
  );
}
