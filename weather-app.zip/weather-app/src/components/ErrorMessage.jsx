import styles from "../styles/ErrorMessage.module.css";

/**
 * ErrorMessage — shows a styled error banner.
 * Props:
 *   message — string to display
 */
export default function ErrorMessage({ message }) {
  if (!message) return null;

  return (
    <div className={styles.box} role="alert">
      ❌ {message}
    </div>
  );
}
